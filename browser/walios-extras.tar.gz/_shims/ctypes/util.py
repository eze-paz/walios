def find_library(name): return None
