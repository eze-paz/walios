"""Lightweight ctypes stub for walios (no libffi/_ctypes on wasm).
Satisfies `import ctypes` for libs that reference it but do not make real
FFI calls in the browser (pandas.errors, dateutil.tz Windows path, numpy.ctypeslib
lazy). Any attempt to actually call into native code raises clearly."""
import sys as _sys

__version__ = "1.1.0"

class _StubMeta(type):
    def __getattr__(cls, name): raise AttributeError(name)

class _CData(metaclass=_StubMeta):
    def __init__(self, *a, **k): pass

class Structure(_CData): pass
class Union(_CData): pass
class Array(_CData): pass
class _Pointer(_CData): pass
class _SimpleCData(_CData): pass
class CFuncPtr(_CData): pass
class ArgumentError(Exception): pass
class CField: pass

def _c(name):
    return type(name, (_SimpleCData,), {})

# common scalar types referenced in annotations / sizeof
for _n in ("c_bool c_char c_wchar c_byte c_ubyte c_short c_ushort c_int c_uint "
           "c_long c_ulong c_longlong c_ulonglong c_size_t c_ssize_t c_float "
           "c_double c_longdouble c_char_p c_wchar_p c_void_p c_int8 c_int16 "
           "c_int32 c_int64 c_uint8 c_uint16 c_uint32 c_uint64 py_object").split():
    setattr(_sys.modules[__name__], _n, _c(_n))

def _unavail(*a, **k):
    raise NotImplementedError("ctypes FFI is unavailable in walios (no libffi)")

CDLL = PyDLL = WinDLL = OleDLL = _unavail
cast = pointer = POINTER = byref = addressof = sizeof = alignment = resize = _unavail
create_string_buffer = create_unicode_buffer = memmove = memset = string_at = _unavail
CFUNCTYPE = WINFUNCTYPE = PYFUNCTYPE = _unavail
def get_errno(): return 0
def set_errno(v): return 0
def WinError(code=None, descr=None): return OSError(descr or "WinError (stub)")
def GetLastError(): return 0
def FormatError(code=0): return "stub"
RTLD_LOCAL = 0; RTLD_GLOBAL = 256; DEFAULT_MODE = 0
SIZEOF_TIME_T = 8
class _NamespaceShim: __getattr__ = staticmethod(lambda n: _unavail)
util = _NamespaceShim()
