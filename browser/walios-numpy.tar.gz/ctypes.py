def WinError(code=0, descr=None): return OSError(code or 0, descr or "WinError unavailable")
def CDLL(*a, **k): raise OSError("ctypes.CDLL unavailable in walios")
PyDLL = CDLL
c_int=c_long=c_longlong=c_short=c_byte=c_char=c_uint=c_ulong=c_ulonglong=c_ushort=c_ubyte=int
c_float=c_double=c_longdouble=float
c_char_p=c_void_p=c_wchar_p=c_size_t=c_ssize_t=int
def sizeof(x): return 0
def byref(x): return x
def POINTER(x): return x
def cast(a,b): return a
