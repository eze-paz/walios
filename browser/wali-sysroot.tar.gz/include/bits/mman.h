/* Non-portable */
