# _build_config.py.in is converted into _build_config.py during the meson build process.

from __future__ import annotations


def build_config() -> dict[str, str]:
    """
    Return a dictionary containing build configuration settings.

    All dictionary keys and values are strings, for example ``False`` is
    returned as ``"False"``.

        .. versionadded:: 1.1.0
    """
    return dict(
        # Python settings
        python_version="3.14",
        python_install_dir=r"/site-packages/",
        python_path=r"/home/aezequiel/wali-cross/wali-python",

        # Package versions
        contourpy_version="1.3.0",
        meson_version="1.12.0",
        mesonpy_version="0.16.0",
        pybind11_version="2.13.6",

        # Misc meson settings
        meson_backend="ninja",
        build_dir=r"/home/aezequiel/mpl-src/contourpy-1.3.0/bld/lib/contourpy/util",
        source_dir=r"/home/aezequiel/mpl-src/contourpy-1.3.0/lib/contourpy/util",
        cross_build="True",

        # Build options
        build_options=r"-Dpython.platlibdir=/site-packages --cross-file=/home/aezequiel/mpl-src/wali-cross.txt",
        buildtype="debug",
        cpp_std="c++17",
        debug="True",
        optimization="0",
        vsenv="False",
        b_ndebug="false",
        b_vscrt="from_buildtype",

        # C++ compiler
        compiler_name="clang",
        compiler_version="22.1.3",
        linker_id="ld.lld",
        compile_command="/home/aezequiel/wali-cross/wali-cxx",

        # Host machine
        host_cpu="wasm32",
        host_cpu_family="wasm32",
        host_cpu_endian="little",
        host_cpu_system="linux",

        # Build machine, same as host machine if not a cross_build
        build_cpu="x86_64",
        build_cpu_family="x86_64",
        build_cpu_endian="little",
        build_cpu_system="linux",
    )
